# Changelog

All notable changes to Cantainer are documented here. The format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and versions follow
[Semantic Versioning](https://semver.org/). Before 1.0, any release may contain breaking changes.

Security-relevant changes are listed under **Security**.

## [Unreleased]

## [0.0.3] - 2026-11-12

0.0.2 was tagged but never published: its aarch64 release build failed. Its changes ship in
0.0.3.

### Added
- Release process: `dev/release.sh`, a tag-triggered release workflow with an approval gate,
  crates.io Trusted Publishing, and prebuilt static `cant` binaries for x86_64 and aarch64 Linux
  with signed SHA-256 checksums. `cargo binstall cantainer` downloads them.
- Packages: `.deb` and `.rpm` packages, signed APT and RPM repositories at
  <https://cantainer.github.io/packages/>, and a Homebrew tap (`cantainer/tap/cantainer`).
  The AUR package `cantainer-bin` is prepared and follows once AUR registration reopens.

- Built-in cants for everyday tools: `cat`, `head`, `tail`, `wc`, `diff`, `sed`, `jq`, `grep`,
  `rg`, `find`, `ls`, `tree`, `git`, `vim`, `curl` (no network) and `curl-net`. Each has a
  sandbox test showing it works and can't reach `~/.ssh`.
- Manifests are built into `cant`, so every installation can run them by name.
  Lookup order: `~/.config/cantainer/cants`, then `/etc/cantainer/cants` (new), then built in.
- `cant show NAME` prints a manifest, for example to copy and customize it.
- `cant list` shows where each manifest comes from.
- `cant new PROGRAM` writes a commented, deny-everything manifest to fill in.
- Manifests: `[args] value_operands` and `value_operands_unless` for programs whose first
  operand is a pattern, filter or script rather than a file (`grep`, `rg`, `jq`, `sed`).
- Manifests: `entrypoint.path` may be `~/...` (tools installed in your home), and
  `[env] set` sets variables to fixed values (`$CWD` and `~` expand).
- `capabilities.cants = [...]`: a cant may run these cants, and its rights include theirs, so
  nested `cant run` works. Running an unlisted cant inside another fails with a clear message.
- Built-in `cargo` (offline) and `cargo-net` (for `cargo fetch`): build scripts, proc macros
  and tests run sandboxed, so a malicious dependency can't read `~/.ssh` or, offline, reach the
  network. Tested with a build script that tries to read a key.
- Built-in `agent-sh`: a shell for AI agents that works in the current directory, has no
  network, and runs tools as cants. Guide: `docs/AGENTS.md`.
- `cant completions bash|zsh|fish|elvish|powershell`, and man pages. Packages and the Homebrew
  formula install both.

### Changed
- The example manifests moved from `examples/` to `crates/cantainer/cants/`.

### Removed
- **Breaking:** `cant run NAME` no longer looks in `./examples/`. Use a path
  (`cant run ./examples/x.toml`) or put the manifest in `~/.config/cantainer/cants/`.

### Fixed
- Programs linked by GNU ld inside a cant (Rust on aarch64, C everywhere) came out without the
  executable bit, because path-based `chmod` was refused. Manifests can now declare
  `capabilities.chmod_by_path`, limited to modes within `0775`; `cargo` and `cargo-net` do.
- `cant-launch` builds for aarch64 with musl and for riscv64 (it used a syscall constant the
  `libc` crate doesn't define there).
- A static program in a cant (rustup on arm64) can start dynamically linked programs from an
  `exec` directory: such cants now get execute access to the dynamic loaders.
- `cant list | head` and similar no longer panic when the reader closes the pipe.
- Landlock rule paths are opened with `O_PATH` through `rustix` instead of `landlock::PathFd`.
  On musl, Rust's std strips `O_PATH`. Every granted path was then really opened, so `cant`
  failed with "No such device or address" when there was no controlling terminal (for
  `/dev/tty`), and would have blocked on a FIFO.

### Security
- A repository's `./examples/` directory can no longer choose the manifest for a name you run
  inside it.

## [0.0.1] - 2026-11-12

First release.

### Added
- `cant run`: runs a cant under Landlock (deny-by-default filesystem, TCP when the network is off,
  signal and abstract-socket scopes on newer kernels) and seccomp, then `exec`s the program. Exit
  status, signals and the terminal are the program's own. `--explain` prints the effective policy;
  `--grant PATH[:ACCESS]` adds a grant.
- Powerbox: files named on the command line are granted as the manifest's `[args]` declares.
- Protected paths (`~/.ssh`, `~/.aws`, `~/.gnupg`, credentials, shell startup files, …) that no
  manifest or command-line file can reach without `--grant`.
- Attenuation: a nested `cant` gets the intersection of its own and the enclosing cant's rights,
  enforced by the kernel and explained via `CANT_POLICY`.
- `cant inspect`, `cant list`, `cant check`.
- Strict TOML manifests (`docs/MANIFEST.md`) and examples for `cat`, `curl`, `git` and `vim`.
- Crates: `cantainer`, `cant-manifest`, `cant-policy`, `cant-launch`, `cant-store`.

### Security
- Baseline seccomp filter: refuses `ptrace`, `io_uring`, `bpf`, namespace creation, mounts,
  path-based metadata changes, `TIOCSTI`, x32 syscalls, and sockets the policy doesn't allow.
- Refuses to run on kernels below Landlock ABI 3.

[Unreleased]: https://github.com/cantainer/cantainer/compare/v0.0.3...HEAD
[0.0.3]: https://github.com/cantainer/cantainer/compare/v0.0.1...v0.0.3
[0.0.1]: https://github.com/cantainer/cantainer/releases/tag/v0.0.1
