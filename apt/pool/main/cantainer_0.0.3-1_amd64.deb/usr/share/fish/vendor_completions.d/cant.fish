# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_cant_global_optspecs
    string join \n h/help V/version
end

function __fish_cant_needs_command
    # Figure out if the current invocation already has a command.
    set -l cmd (commandline -opc)
    set -e cmd[1]
    argparse -s (__fish_cant_global_optspecs) -- $cmd 2>/dev/null
    or return
    if set -q argv[1]
        # Also print the command, so this can be used to figure out what it is.
        echo $argv[1]
        return 1
    end
    return 0
end

function __fish_cant_using_subcommand
    set -l cmd (__fish_cant_needs_command)
    test -z "$cmd"
    and return 1
    contains -- $cmd[1] $argv
end

complete -c cant -n "__fish_cant_needs_command" -s h -l help -d 'Print help'
complete -c cant -n "__fish_cant_needs_command" -s V -l version -d 'Print version'
complete -c cant -n "__fish_cant_needs_command" -f -a "run" -d 'Run a cant: `cant run cat notes.txt`'
complete -c cant -n "__fish_cant_needs_command" -f -a "inspect" -d 'Show a cant\'s manifest, binary, digest and capabilities'
complete -c cant -n "__fish_cant_needs_command" -f -a "show" -d 'Print a cant\'s manifest, e.g. to customize it: `cant show git > ~/.config/cantainer/cants/git.toml`'
complete -c cant -n "__fish_cant_needs_command" -f -a "list" -d 'List the cants that `cant run NAME` can find, and where each comes from'
complete -c cant -n "__fish_cant_needs_command" -f -a "new" -d 'Write a starting manifest for a program to ~/.config/cantainer/cants/, denying everything'
complete -c cant -n "__fish_cant_needs_command" -f -a "check" -d 'Check whether this kernel can sandbox cants'
complete -c cant -n "__fish_cant_needs_command" -f -a "completions" -d 'Print a shell completion script: `cant completions bash > /etc/bash_completion.d/cant`'
complete -c cant -n "__fish_cant_needs_command" -f -a "man" -d 'Write the man pages (cant.1, cant-run.1, ...) into DIR, for packaging'
complete -c cant -n "__fish_cant_needs_command" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c cant -n "__fish_cant_using_subcommand run" -l grant -d 'Also grant PATH (default access `r`; `rw`, `rx`, `rwx` also accepted). Needed to reach protected paths such as ~/.ssh. Repeatable' -r
complete -c cant -n "__fish_cant_using_subcommand run" -l explain -d 'Print the effective policy and exit without running anything'
complete -c cant -n "__fish_cant_using_subcommand run" -s h -l help -d 'Print help'
complete -c cant -n "__fish_cant_using_subcommand inspect" -s h -l help -d 'Print help'
complete -c cant -n "__fish_cant_using_subcommand show" -s h -l help -d 'Print help'
complete -c cant -n "__fish_cant_using_subcommand list" -s h -l help -d 'Print help'
complete -c cant -n "__fish_cant_using_subcommand new" -l force -d 'Overwrite an existing manifest, or shadow a built-in one'
complete -c cant -n "__fish_cant_using_subcommand new" -s h -l help -d 'Print help'
complete -c cant -n "__fish_cant_using_subcommand check" -s h -l help -d 'Print help'
complete -c cant -n "__fish_cant_using_subcommand completions" -s h -l help -d 'Print help'
complete -c cant -n "__fish_cant_using_subcommand man" -s h -l help -d 'Print help'
complete -c cant -n "__fish_cant_using_subcommand help; and not __fish_seen_subcommand_from run inspect show list new check completions man help" -f -a "run" -d 'Run a cant: `cant run cat notes.txt`'
complete -c cant -n "__fish_cant_using_subcommand help; and not __fish_seen_subcommand_from run inspect show list new check completions man help" -f -a "inspect" -d 'Show a cant\'s manifest, binary, digest and capabilities'
complete -c cant -n "__fish_cant_using_subcommand help; and not __fish_seen_subcommand_from run inspect show list new check completions man help" -f -a "show" -d 'Print a cant\'s manifest, e.g. to customize it: `cant show git > ~/.config/cantainer/cants/git.toml`'
complete -c cant -n "__fish_cant_using_subcommand help; and not __fish_seen_subcommand_from run inspect show list new check completions man help" -f -a "list" -d 'List the cants that `cant run NAME` can find, and where each comes from'
complete -c cant -n "__fish_cant_using_subcommand help; and not __fish_seen_subcommand_from run inspect show list new check completions man help" -f -a "new" -d 'Write a starting manifest for a program to ~/.config/cantainer/cants/, denying everything'
complete -c cant -n "__fish_cant_using_subcommand help; and not __fish_seen_subcommand_from run inspect show list new check completions man help" -f -a "check" -d 'Check whether this kernel can sandbox cants'
complete -c cant -n "__fish_cant_using_subcommand help; and not __fish_seen_subcommand_from run inspect show list new check completions man help" -f -a "completions" -d 'Print a shell completion script: `cant completions bash > /etc/bash_completion.d/cant`'
complete -c cant -n "__fish_cant_using_subcommand help; and not __fish_seen_subcommand_from run inspect show list new check completions man help" -f -a "man" -d 'Write the man pages (cant.1, cant-run.1, ...) into DIR, for packaging'
complete -c cant -n "__fish_cant_using_subcommand help; and not __fish_seen_subcommand_from run inspect show list new check completions man help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
