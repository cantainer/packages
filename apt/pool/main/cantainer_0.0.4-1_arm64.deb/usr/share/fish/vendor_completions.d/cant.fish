# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_cant_global_optspecs
    string join \n h/help V/version
end

function __fish_cant_needs_command
    # Figure out if the current invocation already has a command.
    set -l cmd (commandline -opc)
    set -e cmd[1]
    argparse -s (__fish_cant_global_optspecs) -- $cmd 2>/dev/null
    or return
    if set -q argv[1]
        # Also print the command, so this can be used to figure out what it is.
        echo $argv[1]
        return 1
    end
    return 0
end

function __fish_cant_using_subcommand
    set -l cmd (__fish_cant_needs_command)
    test -z "$cmd"
    and return 1
    contains -- $cmd[1] $argv
end

complete -c cant -n "__fish_cant_needs_command" -s h -l help -d 'Print help'
complete -c cant -n "__fish_cant_needs_command" -s V -l version -d 'Print version'
complete -c cant -n "__fish_cant_needs_command" -f -a "run" -d 'Run a cant: `cant run cat notes.txt`'
complete -c cant -n "__fish_cant_needs_command" -f -a "pack" -d 'Make a can from a cant: its program, the program\'s libraries (libc and the loader included), the manifest\'s `[pack]` files and an SBOM, as an OCI layout directory'
complete -c cant -n "__fish_cant_needs_command" -f -a "push" -d 'Push a can (a directory made by `cant pack`) to a registry: `cant push grep.can ghcr.io/you/grep:3.11`. Credentials: CANT_REGISTRY_USER and CANT_REGISTRY_TOKEN'
complete -c cant -n "__fish_cant_needs_command" -f -a "pull" -d 'Download a can from a registry and install it, so `cant run REFERENCE` can run it'
complete -c cant -n "__fish_cant_needs_command" -f -a "inspect" -d 'Show a cant\'s manifest, binary, digest and capabilities'
complete -c cant -n "__fish_cant_needs_command" -f -a "show" -d 'Print a cant\'s manifest, e.g. to customize it: `cant show git > ~/.config/cantainer/cants/git.toml`'
complete -c cant -n "__fish_cant_needs_command" -f -a "list" -d 'List the cants that `cant run NAME` can find, and where each comes from'
complete -c cant -n "__fish_cant_needs_command" -f -a "new" -d 'Write a starting manifest for a program to ~/.config/cantainer/cants/, denying everything'
complete -c cant -n "__fish_cant_needs_command" -f -a "verify" -d 'List unresolved changes that cants made to files that run code outside the sandbox (`.git/hooks`, `.git/config`, `.envrc`, `.vscode`, ...); exits 1 if there are any'
complete -c cant -n "__fish_cant_needs_command" -f -a "diff" -d 'Show what a session changed: `cant diff 7f3a2c`'
complete -c cant -n "__fish_cant_needs_command" -f -a "revert" -d 'Put back the files a session changed, as they were before it'
complete -c cant -n "__fish_cant_needs_command" -f -a "keep" -d 'Accept a session\'s changes, so `cant` stops reporting them'
complete -c cant -n "__fish_cant_needs_command" -f -a "log" -d 'List sessions in which cants changed files that run code outside the sandbox'
complete -c cant -n "__fish_cant_needs_command" -f -a "check" -d 'Check whether this kernel can sandbox cants'
complete -c cant -n "__fish_cant_needs_command" -f -a "completions" -d 'Print a shell completion script: `cant completions bash > /etc/bash_completion.d/cant`'
complete -c cant -n "__fish_cant_needs_command" -f -a "man" -d 'Write the man pages (cant.1, cant-run.1, ...) into DIR, for packaging'
complete -c cant -n "__fish_cant_needs_command" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c cant -n "__fish_cant_using_subcommand run" -l grant -d 'Also grant PATH (default access `r`; `rw`, `rx`, `rwx` also accepted). Needed to reach protected paths such as ~/.ssh. Repeatable' -r
complete -c cant -n "__fish_cant_using_subcommand run" -l explain -d 'Print the effective policy and exit without running anything'
complete -c cant -n "__fish_cant_using_subcommand run" -s h -l help -d 'Print help'
complete -c cant -n "__fish_cant_using_subcommand pack" -s o -l output -d 'Where to write the can (default: ./NAME.can)' -r -F
complete -c cant -n "__fish_cant_using_subcommand pack" -s h -l help -d 'Print help'
complete -c cant -n "__fish_cant_using_subcommand push" -s h -l help -d 'Print help'
complete -c cant -n "__fish_cant_using_subcommand pull" -s h -l help -d 'Print help'
complete -c cant -n "__fish_cant_using_subcommand inspect" -s h -l help -d 'Print help'
complete -c cant -n "__fish_cant_using_subcommand show" -s h -l help -d 'Print help'
complete -c cant -n "__fish_cant_using_subcommand list" -s h -l help -d 'Print help'
complete -c cant -n "__fish_cant_using_subcommand new" -l force -d 'Overwrite an existing manifest, or shadow a built-in one'
complete -c cant -n "__fish_cant_using_subcommand new" -s h -l help -d 'Print help'
complete -c cant -n "__fish_cant_using_subcommand verify" -s h -l help -d 'Print help'
complete -c cant -n "__fish_cant_using_subcommand diff" -s h -l help -d 'Print help'
complete -c cant -n "__fish_cant_using_subcommand revert" -l force -d 'Overwrite files that changed again after the session'
complete -c cant -n "__fish_cant_using_subcommand revert" -s h -l help -d 'Print help'
complete -c cant -n "__fish_cant_using_subcommand keep" -s h -l help -d 'Print help'
complete -c cant -n "__fish_cant_using_subcommand log" -s h -l help -d 'Print help'
complete -c cant -n "__fish_cant_using_subcommand check" -s h -l help -d 'Print help'
complete -c cant -n "__fish_cant_using_subcommand completions" -s h -l help -d 'Print help'
complete -c cant -n "__fish_cant_using_subcommand man" -s h -l help -d 'Print help'
complete -c cant -n "__fish_cant_using_subcommand help; and not __fish_seen_subcommand_from run pack push pull inspect show list new verify diff revert keep log check completions man help" -f -a "run" -d 'Run a cant: `cant run cat notes.txt`'
complete -c cant -n "__fish_cant_using_subcommand help; and not __fish_seen_subcommand_from run pack push pull inspect show list new verify diff revert keep log check completions man help" -f -a "pack" -d 'Make a can from a cant: its program, the program\'s libraries (libc and the loader included), the manifest\'s `[pack]` files and an SBOM, as an OCI layout directory'
complete -c cant -n "__fish_cant_using_subcommand help; and not __fish_seen_subcommand_from run pack push pull inspect show list new verify diff revert keep log check completions man help" -f -a "push" -d 'Push a can (a directory made by `cant pack`) to a registry: `cant push grep.can ghcr.io/you/grep:3.11`. Credentials: CANT_REGISTRY_USER and CANT_REGISTRY_TOKEN'
complete -c cant -n "__fish_cant_using_subcommand help; and not __fish_seen_subcommand_from run pack push pull inspect show list new verify diff revert keep log check completions man help" -f -a "pull" -d 'Download a can from a registry and install it, so `cant run REFERENCE` can run it'
complete -c cant -n "__fish_cant_using_subcommand help; and not __fish_seen_subcommand_from run pack push pull inspect show list new verify diff revert keep log check completions man help" -f -a "inspect" -d 'Show a cant\'s manifest, binary, digest and capabilities'
complete -c cant -n "__fish_cant_using_subcommand help; and not __fish_seen_subcommand_from run pack push pull inspect show list new verify diff revert keep log check completions man help" -f -a "show" -d 'Print a cant\'s manifest, e.g. to customize it: `cant show git > ~/.config/cantainer/cants/git.toml`'
complete -c cant -n "__fish_cant_using_subcommand help; and not __fish_seen_subcommand_from run pack push pull inspect show list new verify diff revert keep log check completions man help" -f -a "list" -d 'List the cants that `cant run NAME` can find, and where each comes from'
complete -c cant -n "__fish_cant_using_subcommand help; and not __fish_seen_subcommand_from run pack push pull inspect show list new verify diff revert keep log check completions man help" -f -a "new" -d 'Write a starting manifest for a program to ~/.config/cantainer/cants/, denying everything'
complete -c cant -n "__fish_cant_using_subcommand help; and not __fish_seen_subcommand_from run pack push pull inspect show list new verify diff revert keep log check completions man help" -f -a "verify" -d 'List unresolved changes that cants made to files that run code outside the sandbox (`.git/hooks`, `.git/config`, `.envrc`, `.vscode`, ...); exits 1 if there are any'
complete -c cant -n "__fish_cant_using_subcommand help; and not __fish_seen_subcommand_from run pack push pull inspect show list new verify diff revert keep log check completions man help" -f -a "diff" -d 'Show what a session changed: `cant diff 7f3a2c`'
complete -c cant -n "__fish_cant_using_subcommand help; and not __fish_seen_subcommand_from run pack push pull inspect show list new verify diff revert keep log check completions man help" -f -a "revert" -d 'Put back the files a session changed, as they were before it'
complete -c cant -n "__fish_cant_using_subcommand help; and not __fish_seen_subcommand_from run pack push pull inspect show list new verify diff revert keep log check completions man help" -f -a "keep" -d 'Accept a session\'s changes, so `cant` stops reporting them'
complete -c cant -n "__fish_cant_using_subcommand help; and not __fish_seen_subcommand_from run pack push pull inspect show list new verify diff revert keep log check completions man help" -f -a "log" -d 'List sessions in which cants changed files that run code outside the sandbox'
complete -c cant -n "__fish_cant_using_subcommand help; and not __fish_seen_subcommand_from run pack push pull inspect show list new verify diff revert keep log check completions man help" -f -a "check" -d 'Check whether this kernel can sandbox cants'
complete -c cant -n "__fish_cant_using_subcommand help; and not __fish_seen_subcommand_from run pack push pull inspect show list new verify diff revert keep log check completions man help" -f -a "completions" -d 'Print a shell completion script: `cant completions bash > /etc/bash_completion.d/cant`'
complete -c cant -n "__fish_cant_using_subcommand help; and not __fish_seen_subcommand_from run pack push pull inspect show list new verify diff revert keep log check completions man help" -f -a "man" -d 'Write the man pages (cant.1, cant-run.1, ...) into DIR, for packaging'
complete -c cant -n "__fish_cant_using_subcommand help; and not __fish_seen_subcommand_from run pack push pull inspect show list new verify diff revert keep log check completions man help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
